import { randomUUID } from 'node:crypto'
import { spawn } from 'node:child_process'
import readline from 'node:readline'

const hook = process.env.AGENT_HARBOR_HOOK
const sessionId = process.env.AGENT_HARBOR_CLAUDE_SESSION_ID
if (typeof hook !== 'string' || !hook.startsWith('/')) throw new Error('AGENT_HARBOR_HOOK must be an absolute path')
if (typeof sessionId !== 'string' || !/^[0-9a-f-]{36}$/i.test(sessionId)) throw new Error('AGENT_HARBOR_CLAUDE_SESSION_ID must be a UUID')

const serverInfo = { name: 'agent-harbor-claude', version: '0.3.0' }
const tools = [
  {
    name: 'ask_user_question',
    description: 'Ask the user a release or implementation question through Agent Harbor and wait for the request-scoped answer.',
    inputSchema: {
      type: 'object', additionalProperties: false, required: ['question', 'options'],
      properties: {
        question: { type: 'string', minLength: 1, maxLength: 500 },
        header: { type: 'string', maxLength: 80 },
        options: { type: 'array', minItems: 1, maxItems: 12, items: { type: 'string', minLength: 1, maxLength: 180 } },
        multiSelect: { type: 'boolean' },
      },
    },
  },
  {
    name: 'submit_plan',
    description: 'Submit a concrete implementation plan to Agent Harbor and wait for approve, reject, or revision feedback.',
    inputSchema: {
      type: 'object', additionalProperties: false, required: ['markdown'],
      properties: {
        title: { type: 'string', maxLength: 160 },
        markdown: { type: 'string', minLength: 1, maxLength: 30000 },
      },
    },
  },
]

function bounded(value, maximum) {
  const text = String(value ?? '').trim()
  return text.length <= maximum ? text : `${text.slice(0, maximum)}…`
}

function runHook(payload) {
  return new Promise((resolve, reject) => {
    const child = spawn(hook, ['ingest', '--source', 'claude-code-managed', '--timeout', '86000'], {
      stdio: ['pipe', 'pipe', 'pipe'], env: process.env,
    })
    let stdout = ''
    let stderr = ''
    child.stdout.on('data', (data) => { if (stdout.length < 1_048_576) stdout += data.toString('utf8') })
    child.stderr.on('data', (data) => { if (stderr.length < 65_536) stderr += data.toString('utf8') })
    child.on('error', reject)
    child.on('close', (code) => {
      if (code !== 0) return reject(new Error(stderr.trim() || `Agent Harbor hook exited with ${code}`))
      try { resolve(JSON.parse(stdout.trim() || '{}')) }
      catch (error) { reject(new Error(`Invalid Agent Harbor response: ${error instanceof Error ? error.message : String(error)}`)) }
    })
    child.stdin.end(JSON.stringify(payload))
  })
}

function questionResult(response) {
  const output = response?.hookSpecificOutput ?? {}
  const updated = output?.decision?.updatedInput ?? output?.updatedInput ?? {}
  return { answers: updated.answers ?? {}, accepted: output?.permissionDecision !== 'deny' }
}

function planResult(response) {
  const decision = response?.hookSpecificOutput?.decision ?? {}
  return { approved: decision.behavior === 'allow', behavior: decision.behavior ?? 'deny', feedback: decision.message ?? '' }
}

async function callTool(name, args = {}) {
  const requestId = `agent-harbor-claude-${name}-${randomUUID()}`
  if (name === 'ask_user_question') {
    const question = bounded(args.question, 500)
    const options = Array.isArray(args.options) ? args.options.slice(0, 12).map((value) => bounded(value, 180)).filter(Boolean) : []
    if (!question || options.length === 0) throw new Error('question and at least one option are required')
    const response = await runHook({
      session_id: sessionId,
      hook_event_name: 'PreToolUse',
      tool_name: 'AskUserQuestion',
      tool_use_id: requestId,
      cwd: process.cwd(),
      title: 'Claude Code · Agent Harbor 托管',
      tool_input: {
        questions: [{
          id: 'managed-question',
          header: bounded(args.header ?? 'Claude 提问', 80),
          question,
          options: options.map((label) => ({ label })),
          multiSelect: args.multiSelect === true,
        }],
      },
    })
    return questionResult(response)
  }
  if (name === 'submit_plan') {
    const markdown = bounded(args.markdown, 30_000)
    if (!markdown) throw new Error('markdown is required')
    const response = await runHook({
      session_id: sessionId,
      hook_event_name: 'PermissionRequest',
      tool_name: 'ExitPlanMode',
      tool_use_id: requestId,
      cwd: process.cwd(),
      title: bounded(args.title ?? 'Claude 计划审阅', 160),
      tool_input: { plan: markdown },
    })
    return planResult(response)
  }
  throw new Error(`Unknown tool: ${name}`)
}

function write(message) { process.stdout.write(`${JSON.stringify(message)}\n`) }

async function handle(message) {
  if (message.method === 'notifications/initialized' || message.method === 'notifications/cancelled') return
  if (message.id === undefined) return
  try {
    let result
    if (message.method === 'initialize') {
      result = { protocolVersion: message.params?.protocolVersion ?? '2025-06-18', capabilities: { tools: { listChanged: false } }, serverInfo }
    } else if (message.method === 'ping') {
      result = {}
    } else if (message.method === 'tools/list') {
      result = { tools }
    } else if (message.method === 'tools/call') {
      const value = await callTool(message.params?.name, message.params?.arguments)
      result = { content: [{ type: 'text', text: JSON.stringify(value) }] }
    } else {
      write({ jsonrpc: '2.0', id: message.id, error: { code: -32601, message: `Method not found: ${message.method}` } })
      return
    }
    write({ jsonrpc: '2.0', id: message.id, result })
  } catch (error) {
    write({
      jsonrpc: '2.0', id: message.id,
      result: { content: [{ type: 'text', text: error instanceof Error ? error.message : String(error) }], isError: true },
    })
  }
}

const lines = readline.createInterface({ input: process.stdin, crlfDelay: Infinity })
for await (const line of lines) {
  if (!line.trim()) continue
  try { await handle(JSON.parse(line)) }
  catch (error) { process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`) }
}

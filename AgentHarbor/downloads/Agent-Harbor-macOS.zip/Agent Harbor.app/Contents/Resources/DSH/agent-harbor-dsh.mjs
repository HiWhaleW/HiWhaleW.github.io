// agent-harbor-managed-v1
// DeepSeek Harness 0.1.1-rc.2 Cordis bridge. It uses only DSH's public
// lifecycle, approval waterfall, and single userQuestions provider seams.
import { appendFileSync } from 'node:fs'
import { spawn, spawnSync } from 'node:child_process'

export const name = 'agent-harbor-dsh'
export const inject = ['agents', 'approval', 'userQuestions']

const managedMarker = 'agent-harbor-managed-v1'

function text(value) {
  if (value instanceof Error) return value.message
  if (typeof value === 'string') return value
  try { return JSON.stringify(value) } catch { return String(value) }
}

function terminalName(environment) {
  const program = String(environment.TERM_PROGRAM ?? environment.LC_TERMINAL ?? '').toLowerCase()
  const bundle = String(environment.__CFBundleIdentifier ?? '').toLowerCase()
  if (program.includes('iterm') || bundle.includes('iterm')) return 'iTerm2'
  if (program.includes('apple_terminal') || bundle === 'com.apple.terminal') return 'Terminal'
  if (program.includes('ghostty') || bundle.includes('ghostty')) return 'Ghostty'
  if (program.includes('warp') || bundle.includes('warp')) return 'Warp'
  if (program.includes('wezterm') || bundle.includes('wezterm')) return 'WezTerm'
  if (bundle === 'com.openai.codex') return 'Codex Desktop'
}

function terminalBundleId(environment) {
  const bundle = String(environment.__CFBundleIdentifier ?? '').trim()
  return bundle.length > 0 ? bundle : undefined
}

function lastUnmatchedApprovalId(events, req, claimed) {
  const decided = new Set()
  for (let index = events.length - 1; index >= 0; index -= 1) {
    const event = events[index]
    if (event.type === 'approval/decided') decided.add(event.data.id)
    if (event.type !== 'approval/asked') continue
    const id = event.data.id
    if (decided.has(id) || claimed.has(id)) continue
    if ((req.callId ?? null) !== (event.data.callId ?? null)) continue
    return id
  }
}

function questionPayload(request, identity, requestId) {
  const plan = request.questions.find((question) => question.intent?.kind === 'plan-review')
  if (plan !== undefined) {
    return {
      ...identity,
      hook_event_name: 'approval/requested',
      request_id: requestId,
      tool_name: 'exitplanmode',
      title: plan.header ?? 'Plan review',
      tool_input: {
        plan: plan.detail,
        questions: request.questions,
      },
    }
  }
  return {
    ...identity,
    hook_event_name: 'question/requested',
    request_id: requestId,
    tool_name: 'askuserquestion',
    tool_input: { questions: request.questions },
  }
}

export function apply(ctx, config = {}) {
  const hookExecutable = config.hookExecutable
  if (typeof hookExecutable !== 'string' || !hookExecutable.startsWith('/')) {
    throw new Error('agent-harbor DSH bridge requires an absolute hookExecutable')
  }
  const responseTimeoutSeconds = Number(config.responseTimeoutSeconds ?? 86400)
  const auditPath = process.env.AGENT_HARBOR_DSH_PROTOCOL_LOG
  const liveChildren = new Set()
  const pending = new Map()
  const claimedApprovalIds = new Set()
  const ran = new Set()
  const failed = new Set()
  const disposedSessions = new Set()
  let epoch = 1
  let sequence = 0

  function audit(direction, payload) {
    if (typeof auditPath !== 'string' || auditPath.length === 0) return
    appendFileSync(auditPath, `${JSON.stringify({
      marker: managedMarker,
      at: new Date().toISOString(),
      direction,
      payload,
    })}\n`, { mode: 0o600 })
  }

  function identity(agent) {
    const parent = ctx.agents.list().find((candidate) => ctx.agents.isOwnedBy(agent.id, candidate))
    const header = agent.session.header
    const parentSession = parent?.id ?? header.parentSession
    const common = {
      session_id: parentSession ?? agent.id,
      cwd: header.cwd ?? process.cwd(),
      project: (header.cwd ?? process.cwd()).split('/').filter(Boolean).at(-1) ?? 'project',
      terminal: terminalName(process.env),
      bundle_id: terminalBundleId(process.env),
      tty: process.env.TTY,
      terminal_session_id: process.env.ITERM_SESSION_ID ?? process.env.TERM_SESSION_ID,
      tmux_pane: process.env.TMUX_PANE,
      pid: process.pid,
      model: agent.options.model,
      dsh_origin: header.origin,
      dsh_parent_session: header.parentSession,
      dsh_delegation_depth: header.delegationDepth,
    }
    if (parentSession !== undefined) common.agent_id = agent.id
    return Object.fromEntries(Object.entries(common).filter(([, value]) => value !== undefined && value !== ''))
  }

  function runHook(payload, { wait = false, signal, key } = {}) {
    const invocationEpoch = epoch
    const token = `${invocationEpoch}:${++sequence}`
    if (key !== undefined) {
      if (pending.has(key)) return Promise.resolve({ state: 'stale' })
      pending.set(key, token)
    }
    audit('dsh-to-harbor', payload)
    return new Promise((resolve) => {
      const args = ['ingest', '--source', 'dsh', '--timeout', String(wait ? responseTimeoutSeconds : 10)]
      const child = spawn(hookExecutable, args, {
        stdio: ['pipe', 'pipe', 'pipe'],
        env: process.env,
      })
      liveChildren.add(child)
      let stdout = ''
      let stderr = ''
      let settled = false
      const finish = (result) => {
        if (settled) return
        settled = true
        liveChildren.delete(child)
        signal?.removeEventListener('abort', onAbort)
        if (key !== undefined && pending.get(key) === token) pending.delete(key)
        audit('harbor-to-dsh', { key, ...result })
        resolve(result)
      }
      const onAbort = () => {
        child.kill('SIGTERM')
        finish({ state: 'cancelled' })
      }
      signal?.addEventListener('abort', onAbort, { once: true })
      child.stdout.on('data', (data) => {
        if (stdout.length < 1_048_576) stdout += data.toString('utf8')
      })
      child.stderr.on('data', (data) => {
        if (stderr.length < 65_536) stderr += data.toString('utf8')
      })
      child.on('error', (error) => finish({ state: 'unavailable', error: text(error) }))
      child.on('close', (code) => {
        if (settled) return
        if (invocationEpoch !== epoch || (key !== undefined && pending.get(key) !== token)) {
          finish({ state: 'stale' })
          return
        }
        if (code !== 0 || stdout.trim() === '') {
          finish({ state: 'unavailable', code, stderr })
          return
        }
        try {
          finish({ state: 'answered', value: JSON.parse(stdout) })
        } catch (error) {
          finish({ state: 'unavailable', error: text(error), stdout })
        }
      })
      child.stdin.end(JSON.stringify(payload))
    })
  }

  function emit(agent, hookEventName, extra = {}) {
    void runHook({ ...identity(agent), hook_event_name: hookEventName, ...extra })
  }

  function emitSessionEnd(payload) {
    audit('dsh-to-harbor', payload)
    const child = spawnSync(
      hookExecutable,
      ['ingest', '--source', 'dsh', '--timeout', '10'],
      {
        input: JSON.stringify(payload),
        encoding: 'utf8',
        env: process.env,
        timeout: 10_000,
        maxBuffer: 1_114_112,
      },
    )
    audit('harbor-to-dsh', {
      state: child.status === 0 && child.error === undefined ? 'delivered' : 'unavailable',
      code: child.status,
      signal: child.signal,
      error: child.error === undefined ? undefined : text(child.error),
      stderr: child.stderr?.slice(0, 65_536),
    })
  }

  ctx.on('agent/session-start', ({ agent, source }) => {
    emit(agent, 'SessionStart', { lifecycle_source: source })
  })
  ctx.on('agent/status', ({ agent, status }) => {
    if (status === 'running') {
      ran.add(agent.id)
      failed.delete(agent.id)
      emit(agent, 'Activity', { activity: 'DeepSeek Harness is working' })
    } else if (ran.has(agent.id) && !failed.has(agent.id)) {
      emit(agent, 'Stop', { summary: 'DeepSeek Harness turn completed' })
    }
  })
  ctx.on('agent/error', ({ agent, error, turn, step }) => {
    failed.add(agent.id)
    emit(agent, 'Error', { message: text(error), turn_id: String(turn), dsh_step: step })
  })
  ctx.on('agent/disposed', ({ agent }) => {
    if (disposedSessions.has(agent.id)) return
    disposedSessions.add(agent.id)
    emitSessionEnd({ ...identity(agent), hook_event_name: 'SessionEnd', reason: 'agent/disposed' })
  })
  ctx.on('session/event', (session, event) => {
    audit('dsh-session-event', { sessionId: session.id, header: session.header, event })
  })
  ctx.on('session/disposed', (session) => {
    if (disposedSessions.has(session.id)) return
    disposedSessions.add(session.id)
    const agent = ctx.agents.get(session.id)
    if (agent !== undefined) {
      emitSessionEnd({ ...identity(agent), hook_event_name: 'SessionEnd', reason: 'session/disposed' })
    } else emitSessionEnd({
      session_id: session.id,
      cwd: session.header.cwd,
      hook_event_name: 'SessionEnd',
      reason: 'session/disposed',
    })
  })

  ctx.on('approval/request', async (req) => {
    if (req.signal?.aborted === true) return 'cancelled'
    const approvalId = lastUnmatchedApprovalId(req.agent.session.events, req, claimedApprovalIds)
    if (approvalId === undefined) return 'unavailable'
    claimedApprovalIds.add(approvalId)
    const result = await runHook({
      ...identity(req.agent),
      hook_event_name: 'approval/requested',
      request_id: approvalId,
      tool_name: req.toolName,
      reason: req.reason,
      tool_input: req.callId === undefined ? {} : { call_id: req.callId },
    }, { wait: true, signal: req.signal, key: `approval:${req.agent.id}:${approvalId}` })
    claimedApprovalIds.delete(approvalId)
    if (result.state === 'cancelled') return 'cancelled'
    const outcome = result.value?._agent_harbor_dsh?.outcome
    return ['allowed-once', 'rejected', 'cancelled', 'unavailable'].includes(outcome)
      ? outcome
      : 'unavailable'
  })

  const disposeProvider = ctx.userQuestions.registerProvider({
    async ask(request) {
      const agent = request.agent
      if (agent === undefined) throw new Error('Agent Harbor requires an agent-owned DSH question')
      const requestId = `dsh-question-${agent.id}-${++sequence}`
      const result = await runHook(
        questionPayload(request, identity(agent), requestId),
        { wait: true, signal: request.signal, key: `question:${agent.id}:${requestId}` },
      )
      if (result.state !== 'answered') throw new Error(`Agent Harbor DSH question ${result.state}`)
      const answer = result.value?._agent_harbor_dsh?.answer
      if (!Array.isArray(answer?.answers)) throw new Error('Agent Harbor returned no structured DSH answer')
      return answer
    },
  })

  ctx.effect(() => () => {
    const remainingAgents = [...ctx.agents.list()].sort(
      (left, right) => (right.session.header.delegationDepth ?? 0) - (left.session.header.delegationDepth ?? 0),
    )
    for (const agent of remainingAgents) {
      if (disposedSessions.has(agent.id)) continue
      disposedSessions.add(agent.id)
      emitSessionEnd({ ...identity(agent), hook_event_name: 'SessionEnd', reason: 'bridge/teardown' })
    }
    epoch += 1
    disposeProvider()
    for (const child of liveChildren) child.kill('SIGTERM')
    liveChildren.clear()
    pending.clear()
  }, 'agent-harbor-dsh: teardown')
}
